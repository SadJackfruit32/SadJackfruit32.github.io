from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from flask_mail import Mail
from .config import Config
from flask_migrate import Migrate

 # SETUP
app = Flask(__name__, static_folder='static')
app.config.from_object(Config)

 # UPLOAD FOLDER FOR IMAGES
app.config['UPLOAD_FOLDER'] = 'static/uploads'

 # DATABASE SQL (site.db)
db = SQLAlchemy(app)
migrate = Migrate(app, db)

 # USES BCRYPT TO GENERATE PASSWORD HASH
bcrypt = Bcrypt(app)

 # USES LOGIN MANAGER TO KEEP TRACK USERS
login_manager = LoginManager(app)
login_manager.login_view = 'login'

 # USES FOR RESENT MAIL VERIFICATION (USES PERSONALISED EMAIL)
mail = Mail(app)

from app import routes
