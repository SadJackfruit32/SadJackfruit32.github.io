from flask_wtf import FlaskForm
from wtforms import SelectField, FileField, StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Regexp


class RegistrationForm(FlaskForm):
    # REGISTRATION CONFIGURATION CONTENTS (REQUIRED FOR REGISTRATION OF NEW USER)
    email = StringField('Email', [DataRequired(), Email()])
    name = StringField('Name', [DataRequired(), Length(min=2, max=100)])
    phone = StringField('Phone', [DataRequired()])
    password = PasswordField('Password', [DataRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm Password', [DataRequired(), EqualTo('password')])

    # SECURITY QUESTION FOR ENHANCED WEBSITE AND USER SECURITY
    security_question = SelectField('Security Question', choices=[
        ('pet', 'What is your pets name?'),
        ('favorite_person', 'Who is your favorite person?'),
        ('first_school', 'What was the name of your first school?'),
    ], validators=[DataRequired()])

    # SECURITY ANSWER
    security_answer = StringField('Answer', validators=[DataRequired()])

    # SUBMIT INFORMATION FROM FORM BUTTON LOGIC
    submit = SubmitField('Register')


class LoginForm(FlaskForm):
    # LOGIN CONFIGURATION CONTENTS (REQUIRED FOR LOGIN OF EXISTING USER)
    # SECURITY ANSWER FOR ENHANCED WEBSITE AND USER SECURITY
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    security_answer = StringField('Security Answer', validators=[DataRequired()])


class RequestEvaluationForm(FlaskForm):
    # REQUEST EVALUATION CONFIGURATION (REQUIRED FIELDS FOR UPLOADING OF AN IMAGE)
    comment = StringField('Comment', validators=[DataRequired()])
    contact_method = SelectField('Contact Method', choices=[('email', 'Email'), ('phone', 'Phone')], validators=[DataRequired()])
    photo = FileField('Upload Photo', validators=[DataRequired()])
    submit = SubmitField('Submit')


class RequestResetForm(FlaskForm):
    # REQUEST RESET PASSWORD CONFIGURATION (REQUIRED FIELDS FOR PASSWORD RESET)
    email = StringField('Email', validators=[DataRequired(), Email()])
    submit = SubmitField('Request Password Reset')


class ResetPasswordForm(FlaskForm):
    # NEW PASSWORD CONFIGURATION (REQUIRED FIELDS AND CONTENT OF PASSWORD FOR THE NEW PASSWORD TO BE VALID)
    password = PasswordField('New Password', validators=[
        DataRequired(),
        Length(min=12, message="Password must be at least 12 characters long"),             # MINIMUM LENGTH
        Regexp(r'[A-Z]', message="Password must contain at least one uppercase letter"),    # UPPERCASE REQUIREMENT
        Regexp(r'[a-z]', message="Password must contain at least one lowercase letter"),    # LOWERCASE REQUIREMENT
        Regexp(r'\d', message="Password must contain at least one number"),                 # NUMERIC VALUE REQUIREMENT
        Regexp(r'[@$!%*?&]', message="Password must contain at least one special character") # SPECIAL CHARACTER REQUIREMENT
    ])

    # RE-WRITE THE PASSWORD TO ENSURE THE SAME PASSWORD IS USED AND NO MISTAKES HAVE BEEN MADE
    confirm_password = PasswordField('Confirm New Password', validators=[
        DataRequired(),
        EqualTo('password', message="Passwords must match")  # ENSURING PASSWORDS WILL MATCH
    ])

    # SUBMIT BUTTON LOGIC
    submit = SubmitField('Reset Password')