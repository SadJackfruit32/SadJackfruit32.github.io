from app import app, db, bcrypt, mail
from app.models import User, EvaluationRequest
from app.forms import RegistrationForm, LoginForm, RequestEvaluationForm, RequestResetForm, ResetPasswordForm

from flask_login import login_user, current_user, logout_user, login_required
from flask_mail import Message
from flask import render_template, request, redirect, flash, url_for

from werkzeug.security import generate_password_hash
from werkzeug.utils import secure_filename

import os

# CONFIGURATION FOR IMAGE UPLOAD ON DATABASE (LIMITATIONS)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
allowed_file_types = {'jpg', 'jpeg', 'png', 'gif'}


# FUNCTION FOR DETERMINING UPLOADED FILES
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_file_types


@app.route('/register', methods=['GET', 'POST'])
def register():
    # GETS FORMS CLASS FOR REGISTRATION CONFIGURATION
    form = RegistrationForm()
    if form.validate_on_submit():

        # PREVENTS SQL INJECTION
        existing_user = User.query.filter_by(email=form.email.data).first()
        if existing_user:
            flash('Email address already in use. Please use a different email.', 'danger')
            return redirect(url_for('register'))

        # IF SUCCESSFUL CREATES NEW USER AND ASSIGNED ACCORDING ROLES AND DATABASE INFORMATION
        # BACKDOOR FOR ADMIN PRIVILEGES IF DATABASE EMPTY AND NO ADMIN (UNCOMMENT)
        """ role = 'admin' if form.email.data == 'admin@example.com' else 'user' """
        role = 'user'

        # NEW USER DATA
        new_user = User(
            email=form.email.data,
            name=form.name.data,
            phone=form.phone.data,

            # SALT LENGTH FOR ENTROPY ENCRYPTION LENGTH 32 (HIGH)
            password_hash=generate_password_hash(form.password.data, method='pbkdf2:sha256', salt_length=32),
            role=role
        )

        # ADDS USER AND USER DATA TO SITE.db SQL DATABASE
        db.session.add(new_user)

        # ADDS TO DATABASE
        db.session.commit()
        print("TEST COMMIT")

        flash('Registration successful!', 'success')
        return redirect(url_for('login'))

    elif form.is_submitted():
        flash('Registration unsuccessful.', 'danger')
        print("FAILED REGISTER")

    return render_template('register.html', form=form)


@app.route("/login", methods=['GET', 'POST'])
def login():
    # GETS FORMS CLASS FOR LOGIN
    form = LoginForm()

    if form.validate_on_submit():
        # GETS USER BY EMAIL
        user = User.query.filter_by(email=form.email.data).first()

        if user:
            # IF ACCOUNT IS FLAGGED AS BLOCKED MESSAGE FLASHES AND ACCOUNT IS NOT PERMITTED TO LOGIN
            if user.blocked:
                flash('Your account is blocked. Please contact an administrator.', 'danger')
                return redirect(url_for('login'))

            # IF PASSWORD IS CORRECT
            if user.check_password(form.password.data):
                # FAILED ATTEMPTS FOR USER BLOCK IS RESET TO 0
                user.failed_attempts = 0
                # ENSURES ACCOUNT IS NOT BLOCKED AFTER SUCCESSFUL LOGIN (FOR ADMIN PRIV WHEN USER IS UNBLOCKED
                # VIA ADMIN DASHBOARD
                user.blocked = False

                # UPDATES DATABASE
                db.session.commit()

                login_user(user)
                return redirect(url_for('home'))

            else:
                # IF PASSWORD IS NOT CORRECT INCREMENT FAILED ATTEMPTS VARIABLE
                user.failed_attempts += 1

                # IF FAILED ATTEMPTS = 3
                # BLOCK USER AND UPDATE DATABASE
                if user.failed_attempts >= 3:
                    user.blocked = True
                    db.session.commit()
                    flash('Your account is blocked. Please contact an administrator.', 'danger')
                else:
                    flash('Incorrect email or password', 'danger')
                    db.session.commit()

        else:
            flash('Login unsuccessful. Check email and password.', 'danger')

    return render_template('login.html', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))


@app.route('/request_evaluation', methods=['GET', 'POST'])
@login_required
def request_evaluation():
    # GETS REQUEST EVALUATION FROM FORM CLASS
    form = RequestEvaluationForm()

    if request.method == 'POST':
        if form.validate_on_submit():
            # INPUT FIELDS
            comment = form.comment.data
            contact_method = form.contact_method.data
            # ENSURE IMAGE IS ATTACHED TO THE UPLOAD OF A EVALUATION REQUEST
            file = request.files.get('photo')

            # UPLOAD FOLDER FOR IMAGE STORAGE (LOCAL)
            if not os.path.exists(app.config['UPLOAD_FOLDER']):
                os.makedirs(app.config['UPLOAD_FOLDER'])

            # CALLS FUNCTION TO ENSURE FILES IS OF RIGHT FORMAT
            # SAVES IMAGE TO ABSOLUTE PATH
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

                # COMMITS TO DATABASE NEW UPLOAD WITH ALL RESPECTIVE FIELDS
                new_request = EvaluationRequest(
                    comment=comment,
                    contact_method=contact_method,
                    photo_filename=filename,
                    user_id=current_user.id
                )

                db.session.add(new_request)
                db.session.commit()
                flash('Evaluation request submitted successfully!', 'success')

            else:
                flash('Invalid file type. Please upload a valid image.', 'danger')

            return redirect(url_for('request_evaluation'))

    return render_template('request_evaluation.html', form=form)


@app.route('/admin_dashboard')
@login_required
def admin_dashboard():
    # IF USER HAS ADMIN ROLE
    if current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('home'))

    # OPEN ADMIN DASHBOARD AND DISPLAY DATABASE CONTENTS
    requests = EvaluationRequest.query.all()
    users = User.query.all()

    # DEBUGGGG
    print(f"Current User Role: {current_user.role}")
    print(f"Requests Count: {len(requests)}")
    print(f"Users Count: {len(users)}")
    requests = EvaluationRequest.query.all()

    return render_template('admin_dashboard.html', requests=requests, users=users)


@app.route('/make_admin/<int:user_id>')
@login_required
def make_admin(user_id):
    # ALLOWS USERS TO MAKE OTHER USERS ADMIN IN CASE NO ADMINS
    if current_user.role != 'admin':
        flash('You do not have permission.', 'danger')
        return redirect(url_for('home'))

    user = User.query.get_or_404(user_id)
    user.role = 'admin'
    db.session.commit()
    return redirect(url_for('admin_dashboard'))


@app.route('/delete_request/<int:request_id>', methods=['POST'])
@login_required
def delete_request(request_id):
    # GET EVALUATION REQUEST FROM DATABASE AND DELETE UPLOADED IMAGE
    request_to_delete = EvaluationRequest.query.get(request_id)
    if request_to_delete:
        photo_filename = request_to_delete.photo_filename
        db.session.delete(request_to_delete)
        db.session.commit()

        # DELETE PHOTO FROM LOCAL
        if photo_filename:
            try:
                photo_path = os.path.join(app.config['UPLOAD_FOLDER'], photo_filename)
                if os.path.exists(photo_path):
                    os.remove(photo_path)  # Delete the file
                    flash('Photo deleted successfully!', 'success')
                else:
                    flash('Photo file not found, but request was deleted.', 'warning')
            except Exception as e:
                flash(f'Error deleting the photo file: {e}', 'danger')

        return redirect(url_for('admin_dashboard'))

    else:
        flash('Request not found.', 'danger')
        return redirect(url_for('admin_dashboard'))


def send_reset_email(user, token):
    # GENERATE HYPERLINK FOR EMAIL AND SEND OUT AN EMAIL USING (PERSONAL EMAIL) FOR THE PASSWORD RESET
    reset_url = url_for('reset_token', token=token, _external=True)

    # CREATES THE CONTENTS OF THE EMAIL
    msg = Message('Password Reset Request',
                  sender='noreply@demo.com',
                  recipients=[user.email])
    msg.body = f'''To reset your password, visit the following link:
    {reset_url}

    If you did not make this request, simply ignore this email.
    '''
    mail.send(msg)


@app.route('/reset_request', methods=['GET', 'POST'])
def reset_request():
    # GETS CONFIGURATION FROM REQUEST FORM
    form = RequestResetForm()
    if form.validate_on_submit():

        # GENERATES A NEW TOKEN TO RESET USERS PASSWORD CONFIGURATION
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            token = user.get_reset_token()

            # USES SENDING FUNCTION TO SEND EMAIL
            send_reset_email(user, token)
            flash('An email has been sent with instructions to reset your password.', 'info')
            return redirect(url_for('login'))

        else:
            flash('No account found with that email.', 'warning')
    return render_template('reset_request.html', form=form)


@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_token(token):
    # TAKES TOKEN FROM RESET REQUEST TO VERIFY IF VALID AND NOT EXPIRED
    # IF TOKEN IS EXPIRED THE RESET HYPERLINK CONFIGURATION WILL NOT ALLOW FOR THE RESET OF THE PASSWORD
    user = User.verify_reset_token(token)
    if user is None:
        flash('That is an invalid or expired token.', 'warning')
        return redirect(url_for('reset_request'))

    # GETS RESET PASSWORD FORM CONFIGURATION
    form = ResetPasswordForm()
    if form.validate_on_submit():

        # PASSWORD CHECKS FOR VALIDITY
        hashed_password = generate_password_hash(form.password.data)
        user.password_hash = hashed_password
        db.session.commit()
        flash('Your password has been updated!', 'success')
        return redirect(url_for('login'))

    return render_template('reset_token.html', form=form, token=token)


@app.route('/admin/unblock/<int:user_id>', methods=['GET'])
@login_required
def unblock_user(user_id):
    # USED TO UNBLOCK USERS IF ADMIN PRIVS ARE ASSIGNED
    user = User.query.get(user_id)

    # UNBLOCKS THE USER
    if user:
        user.blocked = False
        db.session.commit()
        flash(f'User {user.email} has been unblocked successfully!', 'success')

    else:
        flash('User not found.', 'danger')
    return redirect(url_for('admin_dashboard'))


@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')