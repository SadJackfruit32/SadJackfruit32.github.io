from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import URLSafeTimedSerializer as Serializer
from flask import current_app


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# USER CONFIGURATION CONTENT
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(15), nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(10), nullable=False, default='user')

    # USED TO ENHANCE WEBSITE SECURITY (BRUTE FORCE ATTACKS)
    blocked = db.Column(db.Boolean, default=False)
    failed_attempts = db.Column(db.Integer, default=0)

    # CONTENTS OF SECURITY QUESTION FIELDS (ENHANCED WEBSITE SECURITY)
    security_question = db.Column(db.String(120), nullable=False, default="Your favorite color?")
    security_answer_hash = db.Column(db.String(128), nullable=False, default="")

    # CREATES PASSWORD HASHING FOR USER WITH "PBKDF2" WITH A HIGH ITERATION COUNT FOR SECURITY ENHANCEMENTS
    # 1 MILLION ITERATIONS
    def set_password(self, password):
        self.password_hash = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16, iterations=1000000)

    # CHECKS IF PROVIDED PASSWORDS MATCH THE HASHED ITERATION OF THE PASSWORD
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    # CREATING SECURITY ANSWER HASHING
    def set_security_answer(self, answer):
        self.security_answer_hash = generate_password_hash(answer)

    # CHECKS IF PROVIDED SECURITY QUESTION ANSWERS MATCH THE HASHED ITERATION OF THE SECURITY QUESTION
    def check_security_answer(self, answer):
        return check_password_hash(self.security_answer_hash, answer)

    # GENERATES A TOKEN WHICH CAN BE UTILISED BY THE USER TO RESET THEIR PASSWORD
    def get_reset_token(self, expires_sec=1800):
        s = Serializer(current_app.config['SECRET_KEY'])
        return s.dumps({'user_id': self.id}, salt=current_app.config['SECURITY_PASSWORD_SALT'])

    # IF PASSWORD RESET TRIGGERED - VERIFIES TOKEN AND RETURNS THE USERS CONTENTS IF TOKEN IS VALID
    @staticmethod
    def verify_reset_token(token):
        suser = Serializer(current_app.config['SECRET_KEY'])
        try:
            user_id = suser.loads(token, salt=current_app.config['SECURITY_PASSWORD_SALT'], max_age=1800)['user_id']

        except:
            return None
        return User.query.get(user_id)


# USER UPLOAD IMAGE CONFIGURATION CONTENTS
class EvaluationRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    comment = db.Column(db.Text, nullable=False)
    contact_method = db.Column(db.String(20), nullable=False)
    photo_filename = db.Column(db.String(100))
    user = db.relationship('User', backref='requests')
