
  ----------------------------------
  Flask Antiques Marketplace Project
  ----------------------------------

  This folder contains all the code required to launch a secure antiques marketplace website on your local machine using Flask.

  

  ----------------------------------
  Setup Instructions
  ----------------------------------
  1. Execute 'website setup local host.bat'

  This will automatically download pip and required dependencies
    - blinker==1.9.0  
    - click==8.1.7  
    - colorama==0.4.6  
    - Flask==3.0.3  
    - itsdangerous==2.2.0  
    - Jinja2==3.1.4  
    - MarkupSafe==3.0.2  
    - Werkzeug==3.1.3

  Setup a virtual enviroment within the terminal and host the contents of the website locally
  To shut down the local enviroment, simply close the running script.
  IP adress for your local host will be shown in the .bat

