
                          UDP Encryption Protocol Simulation

  What is it?
  -----------

  This project aims to simulate a message transmission on the users local host router via UDP encryption with 
  simulated packet loss which is controllable in given percentages.

  Interface
  -------------

  The project utilises a simple terminal like interface which can be used to manipualte the message being sent,
  the packet losses percentage ratio, and to visually inspect the encryption in real time.

  Liscense
  -------------

  © 2025 [Alex Perello Baque] alias [SadJackfruit32]. All rights reserved. Distributed under CC BY-NC-ND 4.0.
  This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International 
  License (CC BY-NC-ND 4.0).

  You are free to download and share this project as-is for personal and educational use only. Commercial use, 
  redistribution, modification, or reuse of any code or assets is strictly prohibited.

  To see  more liscensing details visit 
  https://github.com/SadJackfruit32/SadJackfruit32.github.io?tab=License-1-ov-file
  
  