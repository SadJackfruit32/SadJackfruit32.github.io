package org.finalServerTCP;

public class Packet {

    // Contents of packet class
    private int sourcePort;
    private int destinationPort;
    private int sequenceNumber;
    private int ackNumber;


    private int checkSum;
    private int octet;
    private byte data[];


    public Packet(int sourcePortInput, int destinationPortInput, int sequenceNumberInput, int ackNumberInput,
                  int checkSumInput, int octetInput, byte[] dataInput) {

        sourcePort = sourcePortInput;
        destinationPort = destinationPortInput;
        sequenceNumber = sequenceNumberInput;
        ackNumber = ackNumberInput;

        checkSum = checkSumInput;
        octet = octetInput;
        data = dataInput;
    }


    // Functions in packets class to get the values stored in packets
    public byte[] getData() {
        return data;
    }

    public int getSourcePort() {
        return sourcePort;
    }

    public int getDestinationPort() {
        return destinationPort;
    }

    public int getSequenceNumber() {
        return sequenceNumber;
    }

    public int getAcknowledgmentNumber() {
        return ackNumber;
    }

    public int getCheckSum() {
        return checkSum;
    }

    public int getOctet() {
        return octet;
    }

}
