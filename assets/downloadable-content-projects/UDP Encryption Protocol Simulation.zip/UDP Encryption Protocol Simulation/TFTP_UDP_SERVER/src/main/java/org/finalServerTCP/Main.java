package org.finalServerTCP;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import org.finalClientTCP.Receiver;


public class Main {
    public static void main(String[] args) {

        int senderPort = 12412;
        int receiverPort = 25568;

        Scanner scanner = new Scanner(System.in);
        packetLossRate = 10;
        boolean runningMenu = true;
        boolean octetRunning = true;

        while (runningMenu) {
            // Menu to list options available
            System.out.println("Menu: ");
            System.out.println("----------------------");
            System.out.println("1. Write to file");
            System.out.println("2. Use default message");
            System.out.println("3. Send file");
            System.out.println("4. Change packet loss rate");
            System.out.println("5. Octet Mode Transfer");
            System.out.println("");
            System.out.println("6. Exit");
            System.out.println("Enter number to select choice... ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            // Switch to allow for user to access different locations in the menu
            switch (choice) {
                case 1:
                    // Writes directly to the file, which is then read from in createPackets to construct the bytes
                    // which are sent across the socket to the receiver project
                    writeToFile();
                    break;

                case 2:
                    // Utilizes a default message which is automatically written to the file
                    useDefaultMessage();
                    break;

                case 3:
                    // startThreadExecutions creates parallel threads for the sender and receiver functions allowing
                    // for active listeners to pick up packets sent on specified ports
                    //startThreadExecutions(null, senderPort, receiverPort);
                    sendPackets(createPackets("send_message.txt", senderPort, receiverPort));
                    runningMenu = false;
                    break;

                case 4:
                    // Used to access the .random function which is used to specify the simulated packet loss amount
                    // in the sendPackets function
                    System.out.println("Current packet loss rate: 0%");

                    while (true) {
                        System.out.println("Enter new packet loss rate (0-9): ");
                        int newPacketLossRate = scanner.nextInt();

                        if (newPacketLossRate >= 0 && newPacketLossRate <= 9) {
                            packetLossRate = 9 - newPacketLossRate;
                            if (newPacketLossRate == 0) {
                                System.out.println("Packet loss rate changed to 0%");
                                packetLossRate = 0;
                            }
                            else {
                                System.out.println("Packet loss rate changed to " + newPacketLossRate + "0%");
                            }
                            break;
                        } else {
                            System.out.println("Invalid input. Please enter a value between 0 and 9.");
                        }
                    }
                    break;

                case 5:
                    // Octet mode, providing different options
                    // 1. Writes to file (sends and receives packets in octet)
                    // 2. Uses default message to write to file (sends and receives packets in octet)
                    // 3. No options for reading and writing to files, user must input text manually,
                    // (sends and receives packets in octet mode)
                    System.out.println("\nSending message via octet mode...");
                    System.out.println("Initiating file transfer through TCP protocol");
                    octet = 1;

                    while (octetRunning) {
                        System.out.println();
                        System.out.println("1. Write to file");
                        System.out.println("2. Use default message");
                        System.out.println("3. Full octet support (no read/write) --- Requires manual text input");
                        System.out.println("Enter number to select choice... ");
                        int octetChoice = scanner.nextInt();

                        switch (octetChoice) {
                            case 1:
                                octetRunning = false;
                                writeToFile();
                                //startThreadExecutions(null, senderPort, receiverPort);
                                sendPackets(createPackets("send_message.txt", senderPort, receiverPort));
                                break;

                            case 2:
                                octetRunning = false;
                                useDefaultMessage();
                                //startThreadExecutions(null, senderPort, receiverPort);
                                sendPackets(createPackets("send_message.txt", senderPort, receiverPort));
                                break;

                            case 3:
                                octetRunning = false;
                                octetNoReadWrite = 1;
                                System.out.println("Write text to send...");
                                Scanner scannerOctetMessage = new Scanner(System.in);
                                String messageForOctetMode = scannerOctetMessage.nextLine();
                                //startThreadExecutions(messageForOctetMode, senderPort, receiverPort);
                                sendPackets(createPackets(messageForOctetMode, senderPort, receiverPort));

                                break;
                        }
                    }

                case 6:
                    // Breaks the menu loop without sending any packets or starting any threads
                    runningMenu = false;
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Error has occurred, please try again.");
            }
        }
        scanner.close();
    }


    public static String fileName = "send_message.txt";
    private static int packetLossRate;
    public static int maxPacketSize = 512;
    public static int octet;
    public static int octetNoReadWrite = 0;
    public static ArrayList<Packet> packets = new ArrayList<>();

    public static ArrayList<Packet> createPackets(String filePathInput, int senderPort, int receiverPort) {
        // Scans for octet mode, if false sends packets normally, if true sends packets via octet mode
        String text;
        if (octetNoReadWrite == 0) {
            // Takes filepath for a TXT file
            String filePath = filePathInput;
            StringBuilder readFile = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String block;
                while ((block = reader.readLine()) != null) {
                    readFile.append(block).append("\n");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            text = readFile.toString();

        }
        else {
            text = filePathInput;
        }

        // Constructs bytes out of the string text
        byte[] bytes = text.getBytes();
        String reconstructText = new String(bytes);

        System.out.println("Contents in BYTES");
        for (int i = 0; i < bytes.length; i++) {
            System.out.print(bytes[i]);
            if (i != bytes.length - 1) {
                System.out.print(" ");
            }
        }

        // ----- DEBUG OPERATIONS ----- // // ----- DEBUG OPERATIONS ----- // // ----- DEBUG OPERATIONS ----- //
        System.out.println("DEBUG MESSAGE: Printing out original TXT ---------- " + text);
        System.out.println("\nDEBUG MESSAGE: Reconstructed Message ---------- " + reconstructText);
        // ------ END OF DEBUG ------ // // ------ END OF DEBUG ------ // // ------ END OF DEBUG ------ //

        // Turns data into an array of packets which can be accessed
        // Splits the bytes into blocks of 512 (maxPacketSize) bytes, each of which are added to the packets class
        // with their respective header and body information
        int blockCount = 0;
        int ackNum = 1;
        byte[] block = null;

        for (int y = 0; y < bytes.length; y += maxPacketSize) {
            int blockLength = Math.min(maxPacketSize, bytes.length - y);
            block = Arrays.copyOfRange(bytes, y, y + blockLength);

            // ----- DEBUG OPERATIONS ----- // // ----- DEBUG OPERATIONS ----- // // ----- DEBUG OPERATIONS ----- //
            // Prints out the segments or "blocks" of data from their byte format to visualize them inside the packets
            // body, followed by other information which was used to represent the packets structure, packet body
            // size (the bytes appearing in the console, the variable assigned to the name of block) depends on the
            // maxPacketSize
            System.out.println("BLOCK COUNT " + blockCount);
            System.out.println("Block " + (blockCount + 1) + ", Bytes: " + blockLength);
            System.out.println("Block Contents: ");
            for (byte b : block) {
                System.out.print(b + " ");
            }
            System.out.println("\n");
            // ------ END OF DEBUG ------ // // ------ END OF DEBUG ------ // // ------ END OF DEBUG ------ //

            // If octet mode true, packets are sent via octet mode
            // If octet mode false, packets are sent via normal mode
            if (octet == 1) {
                if (y + maxPacketSize < bytes.length) {
                    System.out.println("TRIGGERED IF (not me)");
                    packets.add(new Packet(senderPort, receiverPort, blockCount, ackNum, 0, 1, block));
                } else {
                    System.out.println("TRIGGERED ELSE (me)");
                    packets.add(new Packet(senderPort, receiverPort, blockCount, 0, 0, 1, block));
                }
            }
            if (octet == 0) {
                if (y + maxPacketSize < bytes.length) {
                    System.out.println("TRIGGERED IF (not me)");
                    packets.add(new Packet(senderPort, receiverPort, blockCount, ackNum, 0, 0, block));
                } else {
                    System.out.println("TRIGGERED ELSE (me)");
                    packets.add(new Packet(senderPort, receiverPort, blockCount, 0, 0,0, block));
                }
            }

            ackNum++;
            blockCount++;
        }

        // ------ DEBUG OPERATIONS ------ // // ------ DEBUG OPERATIONS ------ // // ------ DEBUG OPERATIONS ------ //
        // Debug for visualizing the last packet in the list of packets sent
        for (int i = 0; i < packets.size(); i++) {
            System.out.println("is it the last packet? " + packets.get(i).getAcknowledgmentNumber());
        }
        System.out.println();

        // Prints out packets in their String or "reconstructed" format to ensure above code implementations
        // function as intended
        for (int i = 0; i < packets.size(); i++) {
            Packet packet = packets.get(i);
            byte[] packetData = packet.getData();
            String reconstructedPacket = new String(packetData);

            System.out.println("Reconstructed Packet " + i + ": " + reconstructedPacket);
        }
        // ------ END OF DEBUG ------ // // ------ END OF DEBUG ------ // // ------ END OF DEBUG ------ //

        return packets;
    }


    // sendPackets function gathers the packets constructed in constructPackets and opens a port and socket to send
    // them to the specified location
    public static void sendPackets(ArrayList<Packet> packets) {
        try {
            // Creates receiverAddress location
            // Creates datagram
            InetAddress receiverAddress = InetAddress.getLocalHost();
            DatagramSocket socket = new DatagramSocket();
            int packetsLost = 0;

            // Convert the data from given values to byte format to match the structure that
            // sending packets through protocols adheres, adding them to an arraylist
            for (int i = 0; i < packets.size(); i++) {
                ArrayList<Byte> packetList = new ArrayList<>();
                packetList.add((byte) packets.get(i).getSourcePort());
                packetList.add((byte) packets.get(i).getDestinationPort());
                packetList.add((byte) packets.get(i).getSequenceNumber());
                packetList.add((byte) packets.get(i).getAcknowledgmentNumber());
                packetList.add((byte) packets.get(i).getCheckSum());
                packetList.add((byte) packets.get(i).getOctet());

                // Since the data, unlike the rest of the packets contents is a stored array of bytes, loop through
                // said array to add them individually to the end arraylist
                for (byte element : packets.get(i).getData()) {
                    packetList.add(element);
                }

                // Take all contents from above that have been added into the packetList and convert them into
                // another array, used to store all the information which the packet contains
                byte[] packetContents = new byte[packetList.size()];
                for (int y = 0; y < packetList.size(); y++) {
                    packetContents[y] = packetList.get(y);
                }

                // Sleep thread
                Thread.sleep(100);

                // Packet loss simulation, used to simulate the loss of packets using a random function from
                // Intellij libraries, depends on packetLossRate variable
                try {
                    Random random = new Random();
                    // If there is no packet loss set to the simulation, packets will send without
                    // using .random
                    if (packetLossRate == 0) {
                        System.out.println("PacketLossRate = " + packetLossRate);
                        DatagramPacket datagramPacket = new DatagramPacket(packetContents, packetContents.length, receiverAddress, packets.get(i).getDestinationPort());
                        System.out.println("\nSent packet with sequence number: " + packets.get(i).getSequenceNumber());

                        socket.send(datagramPacket);
                    }
                    // If there is packet loss set to the simulation, the .random will utilize it accordingly to
                    // simulate the sending of packets with simulated loss (unsuccessful sends)
                    else {
                        int rand = random.nextInt(packetLossRate);
                        if (rand == 0) {
                            packetsLost++;
                            System.out.println("\nPacket lost");
                            if (packetsLost == packets.size()) {
                                for (int y = 0; y < packets.size(); y++) {
                                    DatagramPacket datagramPacket = constructPacket(packets.get(y).getSourcePort(), packets.get(y).getDestinationPort(), packets.get(y).getSequenceNumber(), packets.get(y).getAcknowledgmentNumber(), packets.get(y).getCheckSum(), packets.get(y).getOctet(), packets.get(y).getData());
                                    socket.send(datagramPacket);
                                }
                            }
                        } else {
                            System.out.println("PacketLossRate = " + packetLossRate);
                            DatagramPacket datagramPacket = new DatagramPacket(packetContents, packetContents.length, receiverAddress, packets.get(i).getDestinationPort());
                            System.out.println("\nSent packet with sequence number: " + packets.get(i).getSequenceNumber());
                            socket.send(datagramPacket);
                        }
                    }
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                }
            }

            socket.close();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }



    // Simplification of the construction of packets for specified uses
    public static DatagramPacket constructPacket(int receiverPort, int senderPort, int sequenceNumberInput, int ackNumberInput, int checkSumInput, int octetInput, byte[] dataInput) throws UnknownHostException {
        ArrayList<Packet> constructPacket = new ArrayList<>();
        ArrayList<Byte> bytes = new ArrayList<>();
        InetAddress receiverAddress = InetAddress.getLocalHost();

        for (int i = 0; i != 1; i++) {
            constructPacket.add(new Packet(receiverPort, senderPort, sequenceNumberInput, ackNumberInput, checkSumInput, octetInput, dataInput));
            bytes.add((byte) constructPacket.get(i).getSourcePort());
            bytes.add((byte) constructPacket.get(i).getDestinationPort());
            bytes.add((byte) constructPacket.get(i).getSequenceNumber());
            bytes.add((byte) constructPacket.get(i).getAcknowledgmentNumber());
            bytes.add((byte) constructPacket.get(i).getCheckSum());
            bytes.add((byte) constructPacket.get(i).getOctet());

            for (byte element : constructPacket.get(i).getData()) {
                bytes.add(element);
            }

            byte[] dataConstruct = new byte[bytes.size()];
            for (int e = 0; e < bytes.size(); e++) {
                dataConstruct[e] = bytes.get(e);
            }

            DatagramPacket constructedDatagram = new DatagramPacket(dataConstruct, dataConstruct.length, receiverAddress, constructPacket.get(i).getDestinationPort());

            return constructedDatagram;
        }

        return null;
    }


    // Writes contents that are inputted into the system.in console to the specified file
    private static void writeToFile() {
        Scanner scanner = new Scanner(System.in);

        try (FileWriter writer = new FileWriter(fileName)) {
            System.out.println("Enter message: ");
            String message = scanner.nextLine();
            writer.write(message);
            System.out.println("Message has been written to file with name: " + fileName + "\n");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file");
            throw new RuntimeException(e);
        }
    }

    // Uses the default message provided
    private static void useDefaultMessage() {
        try (FileWriter writer = new FileWriter(fileName)) {
            System.out.println("Applying default message...");
            String message = "This is the default message, lets use some special characters! Maybe even add some new lines?\nCan you see me down here?";
            writer.write(message);
            System.out.println("Message has been written to file with name: " + fileName);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file");
            throw new RuntimeException(e);
        }
    }


    // Starts the execution of parallel threads
    public static void startThreadExecutions(String message, int senderPort, int receiverPort) {
        // If message is null, octet mode is disabled
        if (message == null) {
            Thread receiverThreadOctet = new Thread(() -> Receiver.main(new String[0]));
            receiverThreadOctet.start();

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            sendPackets(createPackets("send_message.txt", senderPort, receiverPort));

            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("\n\n");
            System.out.println("We have reached the end of transmission");
        }
        // Else, if message is not null, octet mode is enabled
        else {
            System.out.println("We are in the else statement of startThreadExecutions");
            System.out.println("I am the message passed into the else statement " + message);
            Thread receiverThreadOctet = new Thread(() -> Receiver.main(new String[0]));
            receiverThreadOctet.start();

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            sendPackets(createPackets(message, senderPort, receiverPort));

            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("\n\n");
            System.out.println("We have reached the end of transmission");
        }
    }
}