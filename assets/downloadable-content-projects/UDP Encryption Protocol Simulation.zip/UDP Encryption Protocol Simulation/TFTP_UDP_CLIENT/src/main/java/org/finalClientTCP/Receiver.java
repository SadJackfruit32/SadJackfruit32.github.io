package org.finalClientTCP;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.IOException;



public class Receiver {
    public static void main(String[] args) {

        int senderPort = 12412;
        int receiverPort = 25568;

        DatagramSocket socket = null; // receiver socket

        ArrayList<Packet> requestingNewPackets = new ArrayList<>();
        ArrayList<Packet> receivedPacketsList = new ArrayList<>();
        int tmp = 0;

        // Opens listener port in while loop at specified ports and socket to allow for the "listening" of incoming
        // packets from server project
        try {
            InetAddress receiverAddress = InetAddress.getLocalHost();
            socket = new DatagramSocket(receiverPort);
            byte[] receiveBuffer = new byte[1024];
            System.out.println("\nReceiver socket opened on port " + receiverPort);
            System.out.println("Receiver is now listening for incoming packets on specified port...");

            try {
                while (true) {
                    // Uses buffer to store incoming packets if received before the previous packet is processed
                    // Listens on specified socket to "catch" incoming packets
                    // Uses socket timeout to detect timeouts
                    DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);

                    System.out.println("Awaiting incoming packets, timeout at 90 seconds...");
                    socket.setSoTimeout(90000);

                    socket.receive(receivePacket); // Receiver socket
                    socket.setSoTimeout(1000); // Timeout 1000 milliseconds, if packets do not arrive, a catch triggers

                    // Received packet data is converted into a new byte array and stored, while the rest are simply
                    // accessed as while packet contents such as sequence numbers and acknowledgment numbers are simply
                    // stored as bytes, while the data was stored by a byte array that required unpacking
                    byte[] receivedData = Arrays.copyOf(receivePacket.getData(), receivePacket.getLength());
                    byte[] data = new byte[receivedData.length - 6];
                    for (int i = 0; i < receivedData.length - 6; i++) {
                        data[i] = receivedData[i + 6];
                    }

                    // Received and unpacked packets are added to the receivedPacketsList
                    Packet receivedPacket = new Packet(receivedData[0], receivedData[1], receivedData[2], receivedData[3], receivedData[4], receivedData[5], data);
                    receivedPacketsList.add(receivedPacket);

                    // ---- DEBUG OPERATIONS ---- // // ---- DEBUG OPERATIONS ---- // // ---- DEBUG OPERATIONS ---- //
                    // Prints statements to console to visualize received packets
                    System.out.println("Received packet with sequence number: " + receivedPacket.getSequenceNumber());
                    System.out.println("Received Packet with Ack Number: " + receivedPacket.getAcknowledgmentNumber());
                    handleReceivedPacket(receivedPacket);
                    // ------ END OF DEBUG ------ // // ------ END OF DEBUG ------ // // ------ END OF DEBUG ------ //

                    // Used to identify the last packet using acknowledgment number
                    if (receivedPacket.getAcknowledgmentNumber() == 0) {
                        System.out.println("\nLast packet received");
                        break;
                    }
                }

                // Specifies when all packets have been received, or final packet has been acknowledged
                System.out.println("\n\nWE HAVE RECEIVED THE FINAL PACKET, COUNTING PACKET CONTENTS");
                int testStop = 1; // if = 0 there are missing packets, if = 1 all packets have arrived
                for (int i = 0; i < receivedPacketsList.size(); i++) {
                    while (receivedPacketsList.get(i).getSequenceNumber() != tmp) {
                        System.out.println("PACKET " + tmp + " RECORDED AS LOST...");

                        // Used to count the missing packets for debug purposes
                        // --- DEBUG OPERATIONS --- // // --- DEBUG OPERATIONS --- // // --- DEBUG OPERATIONS --- //
                        requestingNewPackets.add(new Packet(receiverPort, senderPort, tmp, 0, 0, 0, new byte[]{(byte) 0}));
                        // ----- END OF DEBUG ----- // // ----- END OF DEBUG ----- // // ---- END OF DEBUG ---- //

                        tmp++;
                        testStop = 0;
                    }
                    System.out.println("PACKET " + receivedPacketsList.get(i).getSequenceNumber() + " HAS BEEN RECEIVED");
                    tmp++;
                }

                // Sets 0 when missing packets are found
                if (testStop == 0) {
                    System.out.println("TEST HAS FOUND MISSING PACKETS");
                }
                // Otherwise continues
                else {
                    Thread.sleep(100);
                    System.out.println("\nNO MISSING PACKETS");
                }
            }
            catch (SocketTimeoutException e) {
                System.out.println("Timeout occurred");
                socket.setSoTimeout(2000);
            }

            // ---- DEBUG OPERATIONS ---- // // ---- DEBUG OPERATIONS ---- // // ---- DEBUG OPERATIONS ---- //
            // Used to visualize the whole list of received packets in the given order of arrival
            System.out.println();
            for (int i = 0; i < receivedPacketsList.size(); i++) {
                System.out.println(receivedPacketsList.get(i).getSequenceNumber());
            }
            // ------ END OF DEBUG ------ // // ------ END OF DEBUG ------ // // ------ END OF DEBUG ------ //

            // Uses bubble sort to re-order the list of packets that have been received in the appropriate sequence
            // to avoid data corruption
            System.out.println("We are re-ordering your list to match the correct sequence of packets");
            if (receivedPacketsList.size() != 0) {
                int lengthOfReceived = receivedPacketsList.size();
                for (int i = 0; i < lengthOfReceived - 1; i++) {
                    for (int j = 0; j < lengthOfReceived - i - 1; j++) {
                        if (receivedPacketsList.get(j).getSequenceNumber() > receivedPacketsList.get(j + 1).getSequenceNumber()) {
                            Packet swapper = receivedPacketsList.get(j);
                            receivedPacketsList.set(j, receivedPacketsList.get(j + 1));
                            receivedPacketsList.set(j + 1, swapper);
                        }
                    }
                }

                // Calls reconstructMessage function to concatenate the message and print it to console for
                // visualization purposes
                int octet = receivedPacketsList.get(0).getOctet();
                reconstructMessage(receivedPacketsList, octet);
            }
            else {
                System.out.println("Received packet list does not contain any packets, closing transmission...");
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
                System.out.println("\nReceiver socket closed");
            }
        }
    }


    // Reconstructs message from bytes to string
    // Leaves message in octet mode
    public static void reconstructMessage(ArrayList<Packet> receivedPacketsList, int octet) {
        // When octet is 0, package data is constructed normally back into string format for readable purposes
        if (octet == 0) {
            System.out.println("We have successfully called for reconstructMessage function");
            for (int i = 0; i < receivedPacketsList.size(); i++) {
                System.out.println("Packet " + receivedPacketsList.get(i).getSequenceNumber());
            }

            ArrayList<String> reconstructedData = new ArrayList<>();
            for (int i = 0; i < receivedPacketsList.size(); i++) {
                String test = returnReceivedPacket(receivedPacketsList.get(i));
                reconstructedData.add(test);
            }

            String concatenatedString = concatenateStrings(reconstructedData);
            System.out.println("\n\nReconstructed Data...");
            System.out.println(concatenatedString);

            // Here we write into a txt file
            String writeFileData = "received_message.txt";
            try {
                FileWriter writer = new FileWriter(writeFileData);
                writer.write(concatenatedString);
                writer.close();
                System.out.println("Text has been written to the file successfully");
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        // When octet is 1, package data refrains from constructing and is left in byte format
        else if (octet == 1) {
            System.out.println("We have successfully called for reconstructMessage function");
            for (int i = 0; i < receivedPacketsList.size(); i++) {
                System.out.println("Packet " + receivedPacketsList.get(i).getSequenceNumber());
            }

            ArrayList<Integer> intArray = new ArrayList<>();
            for (Packet packet : receivedPacketsList) {
                byte[] data = packet.getData();

                for (byte b : data) {
                    int intValue = b & 0xFF;
                    intArray.add(intValue);
                }
            }

            System.out.println("\n\nData not constructed, octet mode enabled, produce in bytes...");
            System.out.println("Array of Integers:");
            for (int intValue : intArray) {
                System.out.print(intValue + " ");
            }

            String dataAsString = new String(intArray.toString().getBytes(), StandardCharsets.UTF_8);
            String writeFileData = "received_message.txt";
            try {
                FileWriter writer = new FileWriter(writeFileData);
                writer.write(dataAsString);
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            System.out.println("\nText has been written to the file successfully");
        }

    }

    // Handles printing of data
    public static void handleReceivedPacket(Packet packet) {
        System.out.println("Received Packet Data: " + new String(packet.getData(), StandardCharsets.UTF_8) + "\n");
    }

    public static String returnReceivedPacket(Packet packet) {
        String test = new String(packet.getData(), StandardCharsets.UTF_8);
        return test;
    }

    // Handles the construction of an array type into a single string, avoiding each maxPacketSize data being on
    // new lines when written to specified file or printed to console
    public static String concatenateStrings(ArrayList<String> strings) {
        StringBuilder sb = new StringBuilder();
        for (String str : strings) {
            sb.append(str);
        }
        return sb.toString();
    }

}